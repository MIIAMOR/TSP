#pragma once
#include<iostream>
#include<string>
using namespace std;

#define inFileName "testData.txt";
#define outFileName "testDataSolve.txt";
#define tspGreedyfile "resultGreedy.txt";
#define bestfile "bestData.txt";
#define readmefile "readme.txt"